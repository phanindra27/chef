---------------------------
## Running in a Development Environment
---------------------------

If you are running the "cloud-custodian-deployer" in a Development account then make sure it is running off of the master branch of "custodian-rules" repo. Please check the "README.md" under installation/docs of "cloud-custodian-deployer" repository to see how to setup cloud custodian deployer.


---------------------------
## Rules Development Strategy
---------------------------

For "custodian-rules" repository, there will always be a master , a developer branch and specific release tags.

#### *Development Branch*

Developers can only branch out from the master. No environments run off of this branch. This branch is specifically for developers to write and test rules manually.

#### *Master Branch*

Only Administrators should be have full access to master. All non admin users must have read only access. The DEV AWS account runs the "cloud-custodian-deployer" off of the master. Master will always contain the latest rules.

#### *Tags*

Once all the rules are tested then a tag for that specific release is made from the master. All the non DEV AWS accounts run the "cloud-custodian-deployer" off of a specific tag

#### **Development Process**

- Developers take the branch from master
- Once they are done with a set of rules, they put in a request for an admin to merge these rules back to Master
- Before merging the rules, the admin goes through a list of things to check if the rule files are good. Once they are good then the rules are merged to the master
- If all the testing is done and all the rules look good then we create another tag from the master
- In the deployer, we will have an account to rules repo map where we specify which account runs on which tag. If there is no mapping defined then it runs off of the master
