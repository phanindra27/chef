---------------------------
### Setup Rules
---------------------------

This repository contains all the custodian policies. All the policies are classified into two categories

- common			(Policies that are common across all accounts)
- account specific	(Policies that are specific to an account)

**Common Policies**

All common policies are under [common/rules](common/rules). All the policies are sub categorized into services. There is a sub folder for each service we have a rule for. For example you will have folders for

   [account](common/rules/account)  
   [cloudtrail](common/rules/cloudtrail)  
   [iam](common/rules/iam)  
   [s3](common/rules/s3)  
   [vpc](common/rules/vpc)

**Account Specific Policies**

All the account specific policies will have to be under 'accounts/Account-{ACCOUNT_ID}/rules' folder. All the policies are sub categorized into services. Like common folder there will be a sub folder for each service we have a rule for. For example you will have folders for

   account  
   cloudtrail  
   iam  
   s3  
   vpc    


---------------------------
### Rules Development
---------------------------

All the custodian policy files are in YAML format (.yml). If you the rule files need to comply with the following naming convention

${SERVICE_NAME}_${RULE_NAME}.yml

Where ${SERVICE_NAME} is the service that the rule is for. For example, account or s3 etc
and ${RULE_NAME} is the rule name. For example, root-mfa-check or root-login-detected etc

If the rule is a common rule, then it must be placed under the common folder and it needs to go under its specific service sub-folder it belongs to. For example, a common account rule needs to go under common/rules/account or a common s3 rule needs to go under common/rules/s3

If the rule is an account specific rule, then it must be placed under that specific account sub-folder and it needs to go under its specific service sub-folder it belongs to. For example, an account rule for Account 22323232323 needs to go under accounts/Account-22323232323/rules/account or an s3 rule for Account 22323232323 needs to go under accounts/Account-22323232323/rules/s3


**Convention For Rules Development**

All the custodian rules must follow these conventions.

- It must have a meaningful value for the name property
- If it is sending a notification then the following properties must have a meaningful and appropriate description
	*subject	(Subject of the email)
    *violation_desc	(Short description of violation)
    *action_desc	(Description of the action that must be taken to correct this)

- No hard-coded values must be used, instead use the following place holders where necessary

- The following place holders can be configured through the accounts_config.yml file

| Variable in Custodian YAML file  | Property in accounts_config.yml  |  Description  |
|---|---|---|
| {NOTIFICATION_RECIPIENTS_LIST}  | notifications_list  | It is a comma separated list of email distribution list  |
| {CURRENT_ACCOUNT_ID}  | iam_role_name  | This is the IAM role name that is assumed in that particular account  |
| {IAM_ROLE_NAME}  | account_id  | This is the account id the rule is running against  |


- The following place holders can be configured through the deploy.properties file in the custodian deployer

| Variable in Custodian YAML file  | Property in deploy.properties  |  Description  |
|---|---|---|
| {DEFAULT_NOTIFICATIONS_REGION}  | DEFAULT_NOTIFICATIONS_REGION  | Default region of the main account. For example, us-east-1  |
| {DEFAULT_NOTIFICATIONS_ACCOUNT}  | DEFAULT_NOTIFICATIONS_ACCOUNT  | Account ID of the main account.  |
