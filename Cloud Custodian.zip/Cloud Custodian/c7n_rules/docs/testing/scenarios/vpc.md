# 5 VPC

## 5.1 Detects Updates to VPC NACLs (nacl-update-detected)

The creation and updates to NACLs within a VPC will be monitored closely within the
environment. Modifications to a NACLs could be used to provide unapproved access
to systems within a VPC or in between on-premise AT&T and AWS environments which
could provide unintentional or unauthorized access to data or systems. This rule
assumes that the CloudTrail service is already enabled to stream event data.

This rule will trigger based of of IAM CloudWatch events such as the following:
- CreateNetworkAcl
- CreateNetworkAclEntry
- DeleteNetworkAcl
- DeleteNetworkAclEntry
- ReplaceNetworkAclEntry
- ReplaceNetworkAclAssociation

Upon receiving the notification the event should be investigated to see if actions were expected.


**Custodian Rule Behavior**
- Creating a new Network ACL will trigger a notification
- Creating a new rule in an existing Network ACL will trigger a notification
- Deleting an existing Network ACL will trigger a notification
- Deleting an existing rule in an existing Network ACL will trigger a notification
- Updating an existing rule in an existing Network ACL will trigger a notification
- Modifying the subnet association to a Network ACL will trigger a notification


**Instructions to Trigger Rules**

The following AWS documentation provides steps on how to create a new Network
ACL --> [Creating a Network ACL](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_ACLs.html#CreateACL)

The following AWS documentation provides steps on how to Add, Modify, and Delete
Network ACL Rules --> [Adding and Deleting Rules](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_ACLs.html#Rules)

The following AWS documentation provides steps on how to delete an existing network
ACL --> [Deleting a Network ACL](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_ACLs.html#DeleteNetworkACL)

The following AWS documentation provides steps on how to modify a Network ACL
Subnet Association --> [Changing Network ACL Association](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_ACLs.html#ChangeNetworkACL)

## 5.2 Detects Status of VPC Flow Logs (vpc-flow-logs-enabled)

Enabling VPC Flow Logs on your VPC account provides a history of network traffic
to and from your VPC. This data is useful in detecting and reporting on security
issues. It is also useful for troubleshooting connectivity issues such as rejected
connection requests or unusual traffic patterns.

This rule will check the VPC resource to validate the flow-logs status is
enabled. If it not present or not enabled an notification will be triggered.

Upon receiving the notification the event should be investigated to see if actions were expected.


**Custodian Rule Behavior**
- If VPC Flow Logs is disabled a notification will be triggered
- If the VPC Flow Logs status is not present a notification will be triggered


**Instructions to Trigger Rules**

All new VPCs do not have VPC Flow Logs enabled by default. This rule will trigger
on all newly created VPCs if you do not enable VPC Flow Logs. The following AWS
documentation provides steps on how to create a new VPC --> [Create a New VPC](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/getting-started-ipv4.html#getting-started-create-vpc)

The following AWS documentation provides steps on how to delete VPC Flow Logs
from an existing VPC --> [Deleting a Flow Log](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/flow-logs.html#delete-flow-log)

## 5.3 Detects Updates to Key VPC Resources (vpc-update-detected)

The creation and updates to VPC resources within AWS will be monitored closely
within the environment. Modifications to VPCs could be a sign of intentional
modifications that may lead to unauthorized network access or other security
issues. This rule assumes that the CloudTrail service is already enabled to stream event data.

This rule will trigger based of of IAM CloudWatch events such as the following:
- AcceptVpcPeeringConnection
- AssociateVpcCidrBlock
- AttachInternetGateway
- AttachVpnGateway
- CreateDefaultVpc
- AssociateDhcpOptions
- CreateVpc
- DeleteVpc
- DetachVpnGateway
- DisassociateVpcCidrBlock
- ModifyVpcAttribute


**Instructions to Trigger Rules**

The following AWS documentation provides steps on how to create and accept a VPC
Peering Connection --> [Accepting a VPC Peering Connection](https://docs.aws.amazon.com/AmazonVPC/latest/PeeringGuide/create-vpc-peering-connection.html)

The following AWS documentation provides steps on how to modify a CIDR for a
VPC --> [Change VPC CIDR](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_Subnets.html#vpc-resize)

The following AWS documentation provides steps on how to dissociate a CIDR from a VPC --> [ [disassociate-vpc-cidr-block](https://docs.aws.amazon.com/cli/latest/reference/ec2/disassociate-vpc-cidr-block.html)

The following AWS documentation provides steps on how to add an IGW to a VPC --> [Creating and Attaching an Internet Gateway](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_Internet_Gateway.html#Add_IGW_Attach_Gateway)

The following AWS documentation provides steps on how to add an VGW to a VPC --> [Creating and Attaching  VGW](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_Route_Tables.html#route-tables-vgw)

The following AWS documentation provides steps on how to detach a VGW from a VPC --> [Detaching a VPN Gateway](https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DetachVpnGateway.html)

The following AWS documentation provides steps on how to create a Default VPC --> [Creating a Default VPC](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/default-vpc.html#create-default-vpc)

The following AWS documentation provides steps on how to set DHCP Options on a
VPC --> [Changing the Set of DHCP Options a VPC Uses](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_DHCP_Options.html#ChangingDHCPOptionsofaVPC)

The following AWS documentation provides steps on how to modify VPC attributes -->  [modify-vpc-attribute](https://docs.aws.amazon.com/cli/latest/reference/ec2/modify-vpc-attribute.html)

The following AWS documentation provides steps on how to create a new VPC --> [Create a New VPC](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/getting-started-ipv4.html#getting-started-create-vpc)

The following AWS documentation provides steps on how to delete a VPC --> [Deleting Your VPC](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/working-with-vpcs.html#VPC_Deleting)
