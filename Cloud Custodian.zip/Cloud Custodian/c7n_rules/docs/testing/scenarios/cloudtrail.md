# 2. Cloudtrail

## 2.1 CloudTrail Enabled Check (account-cloudtrail-enabled)

Enabling CloudTrail on your AWS account provides a history of all API calls for your account, including calls from the AWS Management Console, command line tools, AWS SDK, and other AWS Services like CloudFormation. This audit log allows for in depth security analysis and insight into resource changes.

This rule will check the account resource to identify the status of several
CloudTrail components such as:
- CloudTrail enabled in the target region
- CloudTrail Log File Integrity enabled
- CloudTrail Global Services Logging enabled
- CloudTrail KMS Encryption enabled
- CloudTrail Logging enabled

**Custodian Rule Behavior**
- Disabling any of the required features for CloudTrail will trigger a notification
when the Custodian Rule is run


**Instructions to Trigger Rules**

The following AWS documentation provides steps on how to disable CloudTrail in your
region --> [Turning off Logging for a Trail](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-turning-off-logging.html)

The following AWS documentation provides steps on how to disable Log File Integrity --> [Turning off Log File Integrity](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-log-file-validation-enabling.html)

The following AWS documentation provides steps on how to log file encryption --> [Turning off Log File Encryption](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-log-file-encryption-cli.html)
