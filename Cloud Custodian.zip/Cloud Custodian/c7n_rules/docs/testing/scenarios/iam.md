# 3. IAM

## 3.1 Password Policy Out of Compliance (iam-password-policy-check)

Within in AWS you can control and set your password policy. This is important
to keep your AWS environment and account is protected against brute force password
attacks. You can set things such as the minimum length, expiration date, character
complexity, etc.

The following AWS documentation provides steps on how to set the password policy for your account --> [Setting an Account Password Policy for IAM Users](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_passwords_account-policy.html)

### Password Policy Options
- MinimumPasswordLength
- RequireSymbols
- RequireNumbers
- RequireUppercaseCharacters
- RequireLowercaseCharacters
- MaxPasswordAge
- ExpirePasswords

**Custodian Rule Behavior**
- Modifications to the Account Password Policy outside the requirements of the
running Cloud Custodian rule will trigger a notification

**Instructions to Trigger Rules**
The following AWS documentation provides steps on how to set the password policy for your account --> [Setting an Account Password Policy for IAM Users](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_passwords_account-policy.html)

## 3.2 IAM Policy Updates Detected (iam-policy-update-detected)

The creation and updates to IAM policies will be monitored closely within the
environment. Modifications to a user's or role's IAM policy could be used to
elevate the permissions of a user or service which could provide unintentional or
unauthorized access to data or systems.

This rule will trigger based off of IAM CloudWatch events such as CreatePolicy and
CreatePolicyVersion and send out the appropriate notifications. Upon receiving the
notification the event should be investigated to see if actions were expected.

**Custodian Rule Behavior**
- Creation of a new IAM policy will trigger a notification
- An update and saving of an existing IAM policy will trigger a notification

**Instructions to Trigger Rules**

The following AWS documentation provides steps on how to create a new IAM policy --> [Creating IAM Policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_create.html)

The following AWS documentation provides steps on how to update an existing IAM policy --> [Versioning IAM Policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_managed-versioning.html)

## 3.3 IAM Role Updates Detected (iam-role-update-detected)

IAM is the central point of controlled access to an AWS account. Each IAM role leverages
the least privilege by giving the roles the minimal set of actions required. This
rule monitors events to provide or modify the underlying permissions to any role.

This rule will trigger based of of IAM CloudWatch events such as the following:
- AttachRolePolicy
- DetachRolePolicy
- PutRolePolicy
- UpdateAssumeRolePolicy
- AddRoleToInstanceProfile
- DeleteRolePolicy

Upon receiving the notification the event should be investigated to see if actions were expected.

**Custodian Rule Behavior**
- Attaching of a managed IAM policy to a role will trigger a notification
- Removing of a managed IAM policy from a role will trigger a notification
- Attaching of an inline IAM policy to a role will trigger a notification
- Removing of an inline IAM policy from a role will trigger a notification
- Updates to the IAM role trust policy will trigger a notification
- Add an IAM role to an EC2 Instance Profile will trigger a notifications

**Instructions to Trigger Rules**

The following AWS documentation provides steps on how to attach and detach managed
IAM policies as well as working with embedded inline IAM policies --> [Attaching and Detaching IAM Policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_manage-attach-detach.html)

The following AWS documentation provides steps on how to modify an IAM Role's
trust policy --> [Modifying IAM Role Trust Policy](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_manage_modify.html)

The following AWS documentation provides steps on how to modify Instance Profiles
in IAM --> [Working with Instance Profiles](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_switch-role-ec2_instance-profiles.html)
