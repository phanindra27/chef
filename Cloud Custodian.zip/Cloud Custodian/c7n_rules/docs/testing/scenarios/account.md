# 1. Account

## 1.1 Account Access Keys Present (remove-access-keys)

The account level root access keys provides unrestricted access to all the services within your AWS environment, including billing information. It is a best practice to remove these credentials from your root account as it will significantly reduce the risk of unauthorized access to your AWS resources.

This rule will check the IAM summary resource for the presence of root level
access keys and send out the appropriate notification. Upon receiving the
notification the appropriate administrator should remove the access keys from
the account.

The following AWS documentation provides steps on how to create, disable, or delete
root level access keys --> [Managing Access Keys for Your AWS Account](https://docs.aws.amazon.com/general/latest/gr/managing-aws-access-keys.html)

**Custodian Rule Behavior**
- By adding an access key notifications will be sent when the rule is run

- Notifications will not be sent if the access key is removed

- Root access keys cannot be automatically removed by Cloud Custodian because
root level access is required for that action

## 1.2 Root Login Detected (root-login-detected)

It is strongly recommend that the use of root user for an AWS account not be used for your everyday tasks or even the administrative ones. This rule leverages a combination of CloudWatch events to trigger a Cloud Custodian rule deployed as a Lambda to detect the use AWS Root Account usage and sends out the appropriate notification. Upon receiving the notification the appropriate administrator should investigate the activity

The following AWS documentation provides steps on how to login to the AWS console as the Root User -->
[The AWS Account Root User](https://docs.aws.amazon.com/IAM/latest/UserGuide/console.html)

**Custodian Rule Behavior**
- Logging into the AWS console using the root user will trigger this Custodian Rules behavior

## 1.3 Root Account MFA Not Enabled (root-mfa-check)

Having an  MFA device signature adds an extra layer of protection on top of your existing root credentials provides enhanced protections against bad actors from gaining root level access to your AWS root account without the MFA generated passcode.

This rule will check the IAM summary resource to identify if the root account user
has MFA enabled and will send out a notification if it is not. Upon receiving the
notification the appropriate administrator should login to the account to setup MFA
on the account.

**Custodian Rule Behavior**
- If MFA is not enabled on the AWS Root account notifications will be sent when the
Custodian Rule is run. The behavior can be tested by disabling MFA on the account.

- Enabling on the AWS Root Account will stop subsequent notifications from being delivered

**Instructions to Trigger Rules**

The following AWS documentation provides steps on how to enable MFA on your account --> [Enabling a Virtual Multi-factor Authentication (MFA) Device](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_mfa_enable_virtual.html)

The following AWS documentation provides steps on how to disable MFA on your account --> [Disabling a Virtual Multi-factor Authentication (MFA) Device](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_mfa_disable.html)
