---------------------------
### Setup Custodian Rules Repository
---------------------------

Follow these steps to setup the custodian-rules repository for the first time in your code repository (bitbucket etc)

- Create a new repository under your specific project and call it "custodian-rules"
- Make sure you have received "custodian-rules.zip" file
- Unzip this "custodian-rules.zip" file under this "custodian-rules" Repository
- Delete the "custodian-rules.zip" from the "custodian-rules" repository if it is there
- Commit all the files and folders under "custodian-rules" repository

---------------------------
### Description
---------------------------

This repository contains all the custodian policies. All the policies are classified into two categories

- common			(Policies that are common across all accounts)
- account specific	(Policies that are specific to an account)

**Common Policies**

All common policies are under [common/rules](common/rules). All the policies are sub categorized into services. There is a sub folder for each service we have a rule for. For example you will have folders for

   [account](common/rules/account)  
   [cloudtrail](common/rules/cloudtrail)  
   [iam](common/rules/iam)  
   [s3](common/rules/s3)  
   [vpc](common/rules/vpc)

**Account Specific Policies**

All the account specific policies will have to be under 'accounts/Account-{ACCOUNT_ID}/rules' folder. All the policies are sub categorized into services. Like common folder there will be a sub folder for each service we have a rule for. For example you will have folders for

   account  
   cloudtrail  
   iam  
   s3  
   vpc    

---------------------------
### Setup Rules
---------------------------

Please check [docs/setup-rules.md](docs/setup-rules.md)

---------------------------
### Setup Accounts Configuration
---------------------------

Please check [docs/setup-accounts-config.md](docs/setup-accounts-config.md)

---------------------------
### Test Scenarios
---------------------------

Test Scenarios can be found under this folder [docs/testing/scenarios/](docs/testing/scenarios/):

  [account](testing/scenarios/account.md)  
  [cloudtrail](testing/scenarios/cloudtrail.md)  
  [iam](testing/scenarios/iam.md)  
  [s3](testing/scenarios/s3.md)  
  [vpc](testing/scenarios/vpc.md)
