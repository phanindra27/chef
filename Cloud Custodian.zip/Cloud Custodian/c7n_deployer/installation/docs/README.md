---------------------------
## Setup Custodian Deployer Repository
---------------------------

Follow these steps to setup the "cloud-custodian-deployer" repository for the first time in your code repository (bitbucket etc)

- Create a new repository under your specific project and call it "cloud-custodian-deployer"
- Make sure you have received "cloud-custodian-deployer.zip" file
- Unzip this "cloud-custodian-deployer.zip" file under this "cloud-custodian-deployer" Repository
- Delete the "cloud-custodian-deployer.zip" from the "cloud-custodian-deployer" repository if it is there
- Commit all the files and folders under "cloud-custodian-deployer" repository

---------------------------
## Cloud Custodian Environment Provisioning
---------------------------

### Pre-requisites

The following pre-requisite tools must be installed on the instance

- python
- pip

### Bootstraping Environment

Copy the [c7n_bootstrap.sh](../bootstrap-scripts/c7n_bootstrap.sh) script to any location on your instance. For calling the [c7n_bootstrap.sh](../bootstrap-scripts/c7n_bootstrap.sh) script, you need to pass the following parameters in the order they appear in this table

| Parameter  | Description  |
|---|---|
|Rules Repository URL  | This is the "custodian-rules" repository URL. For example, https://bitbucket.org/company/custodian-rules |
|Deployer Repository URL| This is the "cloud-custodian-deployer" repository URL. For example, https://bitbucket.org/company/cloud-custodian-deployer  |
|Username for the Rules Repository  | This is the username used to clone "custodian-rules" repository  |
|Password for the Rules Repository  | This is the application password used to clone "custodian-rules" repository  |
|Username for the Deployer Repository  | This is the username used to clone "cloud-custodian-deployer" repository  |
|Password for the Deployer Repository  | This is the application password used to clone "cloud-custodian-deployer" repository  |
|S3 Bucket for custodian logs  | This is the bucket URL for custodian logs. For example, s3://dev-cloud-custodian-logs  |
|Default Account Number  | This is the main account id that deploys custodian rules in all other accounts.  |
|Default Region  | This is the default region in the default account. For example, us-east-1  |
|Local rules directory  | This is a local rules directory where the "custodian-rules" repository will be cloned. For example, cloud-custodian-rules  |
|Branch Type  | This is a branch type parameter and the value could be either 'master' or 'tag'. Pass 'master' for sandbox deployment and 'tag' for anything else.  |

The bootstrap script does the following

- Installs the required tools  
      git  
      tox  
      shyaml  
- Clones cloud custodian version 0.8.27.3 from Github
- It then replaces "RoleId" with "RoleName" in iam.py script in the cloned repository under c7n/resources/iam.py
- Builds the scripts with tox and run all the required cloud custodian test cases
- Activiate the cloud custodian environment for this instance
- Clones "cloud-custodian-deployer" from local Bitbucket repository. (To see how to setup Bitbucket repository please refer to the first section "Setup Custodian Deployer Repository" of this document)
- Set all the required properties in deploy.properties of "cloud-custodian-deployer"  
- Clones "custodian-rules" from local Bitbucket repository. (It clones all branches required by each account configuration)
- Setup a cron job to fetch updates for the deployer repository every five(5) minutes
- Setup a cron job to clone/fetch updates for the rules repository every five(5) minutes
- Setup a cron job to run time-based rules every one(1) hour
- Setup a cron job to run event-based rules every twelve(12) hours


### Terraform Provisioning
