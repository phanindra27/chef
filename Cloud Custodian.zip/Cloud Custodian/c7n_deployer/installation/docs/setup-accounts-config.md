---------------------------
## Setup Account Configuration
---------------------------

Under [config/accounts](../../config/accounts) folder, you need to have a sub-folder for each account that needs to be monitored through cloud custodian policies.

If this is an initial setup, you can use the sample accounts folder [accounts/Account-22323232323](accounts/Account-22323232323) as a reference.

*Note:* Before actual deployment just make sure that you remove the sample folder [accounts/Account-22323232323](accounts/Account-22323232323) as it will break the deployment since this is not an actual account

### *accounts_config.yml*

This file contains all the account specific configuration for that specific account

| Property  | Description  |
|---|---|
| iam_role_arn  | The role arn that needs to be assumed for this account. For example, arn:aws:iam::22323232323:role/Cloud-Custodian-Role  |
| iam_role_name  | The actual role name that needs to be assumed for this account. For example, Cloud-Custodian-Role  |
| account_id  | The account id for this account. For example, 22323232323  |
| default_region  | The default region for this account. For example, us-east-1  |
| regions  | The regions under this account to which custodian policies need to be deployed. For example<br>- us-west-2<br>- us-east-1<br> or you could just have<br>- all<br>if you want to apply it to all regions |
| notifications_list  | Comma separated list of notification email lists. For example, "['email1@gmail.com', 'email2@gmail.com']"  |
| rules_version  | This is the custodian rules repository version. For example, the value could be '0.1' for tag 0.1 or 'master' for master branch. If this property is not defined then the latest tag will be used for this account. If there are'nt any tags for this repository then master will be used by default.  |


### *rules_metadata.txt*

This file contains all the rules that need to be deployed for this account. It is a simple list of rules, each line contains a path to rule files. The rule files path is relative to the rules repository that is being used by a particular account for example if you want to enable a common s3 rule "s3_s3-bucket-policy-update-detected.yml" then you would specify it like this

common/rules/s3/s3_s3-bucket-policy-update-detected.yml

which means that if this particular account is using tag 0.1 custodian rules which are checked out under /opt/custodian-rules/0.1/custodian-rules then the full path becomes like this '/opt/custodian-rules/0.1/custodian-rules/common/rules/s3/s3_s3-bucket-policy-update-detected.yml'

It can also take regular expressions. For example, if you want to enable all the vpc rules for this account then you would simply say

common/rules/s3/*.yml
OR
common/rules/s3/*
