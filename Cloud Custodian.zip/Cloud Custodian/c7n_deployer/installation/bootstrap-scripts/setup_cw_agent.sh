#!/bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $current_dir/c7n_bootstrap.properties

deployer_local_dir=$1
custodian_log_group=$2
default_region=$3

local_dir="/opt"
temp_cw_conf_file=${local_dir}"/cw_awslogs.conf"
actual_cw_conf_file="/var/awslogs/etc/awslogs.conf"

# Setting Cloudwatch Logs Agent
cd ${local_dir}
if [ -f ${temp_cw_conf_file} ];then
	rm -f ${temp_cw_conf_file}
fi

logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Creating cloudwatch config file in ${temp_cw_conf_file}"
cat <<EOF >${temp_cw_conf_file}
[general]
state_file = /var/awslogs/state/agent-state
## Your config file would have a lot more with the logs that you want to monitor and send to Cloudwatch
EOF

logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Downloading cloudwatch logs setup agent"
cd /root
wget https://s3.amazonaws.com/aws-cloudwatch/downloads/latest/awslogs-agent-setup.py
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} running non-interactive cloudwatch-logs setup script"
python ./awslogs-agent-setup.py --region ${default_region} --non-interactive --configfile=${temp_cw_conf_file}
