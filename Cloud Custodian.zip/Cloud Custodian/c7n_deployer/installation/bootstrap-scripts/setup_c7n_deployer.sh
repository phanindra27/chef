#!/bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $current_dir/c7n_bootstrap.properties

deployer_script_repo_url=$1
deployer_script_repo_user_name=$2
deployer_script_repo_app_password=$3

local_deployer_script_dir="/opt"

deployer_script_repo_basename=$(basename $deployer_script_repo_url)
deployer_script_repo_name=${deployer_script_repo_basename%.*}

# Clone the deployer script repo
final_repo_url="https://$deployer_script_repo_user_name:$deployer_script_repo_app_password@$deployer_script_repo_url"
final_local_repo_dir=$local_deployer_script_dir/$deployer_script_repo_name
clone_repo="false"

# First lets check if the Local Rules Folder exists and it is Git Repo

if [ -d $final_local_repo_dir ]; then
        cd $final_local_repo_dir
        remote_origin_url=`git config --get remote.origin.url`

        # If remote branch is correct then pull the latest changes other wise clone the whole repo again

        if [ "$remote_origin_url" == "$final_repo_url" ]; then
				logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Fetching updates for Custodian Deployer Repository.";
                git fetch origin
				difference=`git diff`
				difference_size=${#difference}
				if [ $difference_size -gt 0 ]; then
					git fetch || 
					{
						logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error pulling changes from Custodian Deployer Repository.";
						logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Command failed 'git pull'";
						exit 1;
					}
				fi
		else
                clone_repo="true"
        fi
else
        clone_repo="true"
fi


# Create the Local Repo folder if it does not exist or the remote origin was not correct

if [ "$clone_repo" == "true" ]; then
        mkdir -p $local_deployer_script_dir
        cd $local_deployer_script_dir
        rm -rf $deployer_script_repo_name
		
		logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Cloning Custodian Deployer Repository.";
		git clone $final_repo_url || 
		{
			logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error cloning Custodian Deployer Repository.";
			logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Command failed 'git clone $final_repo_url'";
			exit 1;
		}
fi

# Removing temp and log files that are older than 10 days

if [[ ! -z "$local_deployer_script_dir" ]] && [[ ! -z "$deployer_script_repo_name" ]]; then
	find $local_deployer_script_dir/$deployer_script_repo_name/tmp/* -type d -ctime +10 | xargs rm -rf
	find $local_deployer_script_dir/$deployer_script_repo_name/logs/* -type d -ctime +10 | xargs rm -rf
fi

