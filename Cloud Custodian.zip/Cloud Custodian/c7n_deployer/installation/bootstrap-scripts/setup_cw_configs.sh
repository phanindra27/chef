#!/bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $current_dir/c7n_bootstrap.properties

deployer_local_dir=$1
custodian_log_group=$2

local_dir="/opt"
actual_cw_conf_file="/var/awslogs/etc/awslogs.conf"

# Iterate over the accounts folders and deploy rules as per the meta data file
for accounts_sub_dir in ${deployer_local_dir}/config/accounts/Account*; do
  if [ -d "$accounts_sub_dir" ]; then
	accounts_config_file="$accounts_sub_dir/accounts_config.yml"
	accounts_sub_folder_name=`echo $(basename $accounts_sub_dir)`
	if [ ! -f "$accounts_config_file" ]; then
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Accounts file [$accounts_config_file] does not exist in [$accounts_sub_dir]"
		continue
	else
	  	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} RUNNING 'cat $accounts_config_file |shyaml get-value AccountsConfig.account_id'"
		account_id=`cat $accounts_config_file |shyaml get-value AccountsConfig.account_id`
				
		regions=`cat "$accounts_config_file" |shyaml get-values AccountsConfig.regions`

		for region in $regions; do

			config_occurence_count=`grep -rnw ${actual_cw_conf_file} -e "\[${account_id}\/${region}\]"|wc -l`

			configs_changed="false"

			logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Adding configuration section for [${account_id}/${region}]"
			if [ $config_occurence_count -eq 0 ];then
				
				# Add the configs here
				echo "[${account_id}/${region}]" >> ${actual_cw_conf_file}
				echo "datetime_format = %b %d %H:%M:%S" >> ${actual_cw_conf_file}
				echo "file = ${deployer_local_dir}/logs/${account_id}/${region}/custodian-*.log" >> ${actual_cw_conf_file}
				echo "buffer_duration = 5000" >> ${actual_cw_conf_file}
				echo "log_stream_name = /${account_id}/${region}" >> ${actual_cw_conf_file}
				echo "initial_position = end_of_file" >> ${actual_cw_conf_file}
				echo "log_group_name = ${custodian_log_group}" >> ${actual_cw_conf_file}
				
				configs_changed="true"
			fi

		done;
		
	fi
  fi
done

if [ "$configs_changed" == "true" ];then
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Cloudwatch log agent configuration has been changed. Hence restarting logs."
	service awslogs restart
fi