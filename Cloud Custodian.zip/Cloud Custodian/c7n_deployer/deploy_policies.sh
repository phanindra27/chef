#!/bin/bash

#current_dir="$( cd "$( dirname "$1" )" && pwd )"

source /opt/c7n_deployer/deploy.properties

current_dir=$LOCAL_DEPLOYER_DIR

logs_dir=$current_dir/"logs"

head_name_for_tag="HEAD"
head_name_for_master="master"

final_repo_url="https://$RULES_REPO_USER:$RULES_REPO_APP_PASSWORD@$RULES_REPO_URL"
final_c7n_deployer_folder=$logs_dir"/"$C7N_DEPLOYER_LOGS_FOLDER
current_timestamp=`echo $(date +"%s")`

c7n_deployer_log_file=$final_c7n_deployer_folder"/deployer-"$current_timestamp".log"

mkdir -p $final_c7n_deployer_folder

touch $c7n_deployer_log_file

branch_type=$1
rules_type=$2
current_account_id=$3

if [ "$#" -eq 0 ]; then
	echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} At least one parameter (Branch_Type) is required" >> $c7n_deployer_log_file
	echo "	1. To run it for master, pass '$RULES_MASTER_REPO_TYPE'. For example 'sh deploy_policies.sh $RULES_MASTER_REPO_TYPE'" >> $c7n_deployer_log_file
	echo "	2. To run it for tags, pass '$RULES_TAG_REPO_TYPE'. For example 'sh deploy_policies.sh $RULES_TAG_REPO_TYPE'" >> $c7n_deployer_log_file
	exit 1
fi

if [[ "$branch_type" != "$RULES_MASTER_REPO_TYPE" ]] && [[ "$branch_type" != "$RULES_TAG_REPO_TYPE" ]]; then
	echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Pass a valid branch type, valid options are :" >> $c7n_deployer_log_file
	echo "	1. $RULES_MASTER_REPO_TYPE" >> $c7n_deployer_log_file
	echo "	2. $RULES_TAG_REPO_TYPE" >> $c7n_deployer_log_file
	exit 1
fi

trimmed_rules_type=`echo ${rules_type//[[:blank:]]/}`

if [[ ! -z "$trimmed_rules_type" ]] && [[ "$trimmed_rules_type" != "$EVENT_BASED_RULE_TYPE" ]] && [[ "$trimmed_rules_type" != "$TIME_BASED_RULE_TYPE" ]]; then
	echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Pass a valid rules type" >> $c7n_deployer_log_file >> $c7n_deployer_log_file
	echo "	1. For event-based rules, pass '$EVENT_BASED_RULE_TYPE'" >> $c7n_deployer_log_file
	echo "			For example 'sh deploy_policies.sh $RULES_MASTER_REPO_TYPE $EVENT_BASED_RULE_TYPE'" >> $c7n_deployer_log_file
	echo "			OR 			'sh deploy_policies.sh $RULES_TAG_REPO_TYPE $EVENT_BASED_RULE_TYPE'" >> $c7n_deployer_log_file
	echo "	2. For time-based rules, pass '$TIME_BASED_RULE_TYPE'" >> $c7n_deployer_log_file
	echo "			For example 'sh deploy_policies.sh $RULES_MASTER_REPO_TYPE $TIME_BASED_RULE_TYPE'" >> $c7n_deployer_log_file
	echo "			OR 			'sh deploy_policies.sh $RULES_TAG_REPO_TYPE $TIME_BASED_RULE_TYPE'" >> $c7n_deployer_log_file
	echo "	3. For all rules, do not pass any rule type" >> $c7n_deployer_log_file
	echo "			For example 'sh deploy_policies.sh $RULES_MASTER_REPO_TYPE'" >> $c7n_deployer_log_file
	echo "			OR 			'sh deploy_policies.sh $RULES_TAG_REPO_TYPE'" >> $c7n_deployer_log_file
	exit 1
fi


# Iterate over the accounts folders and deploy rules as per the meta data file
for accounts_sub_dir in $current_dir/config/accounts/Account*; do
  if [ -d "$accounts_sub_dir" ]; then
	rules_metadata_file="$accounts_sub_dir/rules_metadata.txt"
	accounts_config_file="$accounts_sub_dir/accounts_config.yml"
	accounts_sub_folder_name=`echo $(basename $accounts_sub_dir)`
	if [ ! -f "$rules_metadata_file" ]; then
		echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Rules Metadata file [$rules_metadata_file] does not exist in [$accounts_sub_dir]" >> $c7n_deployer_log_file
		continue
	elif [ ! -f "$accounts_config_file" ]; then
		echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Accounts file [$accounts_config_file] does not exist in [$accounts_sub_dir]" >> $c7n_deployer_log_file
		continue
	else
	  echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.account_id]" >> $c7n_deployer_log_file
		account_id=`cat $accounts_config_file |shyaml get-value AccountsConfig.account_id`
		rules_version=`cat $accounts_config_file |shyaml get-value AccountsConfig.rules_version`

		if [[ ! -z "$current_account_id" ]] && [[ "$current_account_id" != "$account_id" ]]; then
			echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} AccountId [$account_id] does not match the current account id [$current_account_id]" >> $c7n_deployer_log_file
		fi

		#keys_count=`cat accounts-rules-config.yml | shyaml get-value accounts|wc -l`

		#keys_index=$(($keys_count-1))

		#git_revision=`git rev-list --tags --max-count=1`
		#latest_tag=`cd $final_local_repo_dir;git fetch --tags;git describe --tags $git_revision`

		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [git ls-remote --tags $final_repo_url| awk '{print \$2}' | grep -v '{}' | awk -F"/" '{print \$3}' | sort -n -t. -k1,1 -k2,2 -k3,3| tail -1]" >> $c7n_deployer_log_file
		latest_tag=`git ls-remote --tags $final_repo_url| awk '{print \$2}' | grep -v '{}' | awk -F"/" '{print \$3}' | sort -n -t. -k1,1 -k2,2 -k3,3| tail -1`

		if [ ${#rules_version} -eq 0 ]; then
			if [ ${#latest_tag} -eq 0 ]; then
			tag=$head_name_for_master
			else
			tag=$latest_tag
			fi
		else
			remote_tags_ls_count=`git ls-remote --tags $final_repo_url $rules_version`

			if [ ${#remote_tags_ls_count} -eq 0 ]; then
				remote_heads_ls_count=`git ls-remote --heads $final_repo_url $rules_version`
			fi

			if [[ ${#remote_tags_ls_count} -gt 0 ]] || [[ ${#remote_heads_ls_count} -gt 0 ]]; then
				tag=$rules_version
			elif [ ${#latest_tag} -eq 0 ]; then
				tag=$head_name_for_master
			else
				tag=$latest_tag
			fi

		fi

		if [[ "$tag" != "$head_name_for_master" && "$branch_type" == "$RULES_MASTER_REPO_TYPE" ]] || [[ "$tag" == "$head_name_for_master" && "$branch_type" != "$RULES_MASTER_REPO_TYPE" ]]; then
			echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Running branch type [$branch_type]. Account [$account_id] is on tag [$tag], hence skipping this account." >> $c7n_deployer_log_file
			continue;
		fi

		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Account [$account_id] is using version [$tag] rules" >> $c7n_deployer_log_file

		#for key in `seq 0 $keys_index`
		#do
		#        account_map=`cat accounts-rules-config.yml | shyaml get-value accounts.$key`
		#        account=`echo $account_map|shyaml keys-0`

		#        if [ "$account_id" == "$account" ]; then
		#		tag=`echo $account_map|shyaml get-value $account`
		#		echo "Account [$account] uses [$tag] tag"
		#        fi

		#done

		final_local_repo_dir=$LOCAL_RULES_DIR/$tag/$RULES_REPO_NAME
		repo_checked_out="false"

		# First lets check if the Local Rules Folder exists and it is Git Repo
		if [ -d $final_local_repo_dir ]; then
			cd $final_local_repo_dir
			remote_origin_url=`git config --get remote.origin.url`

			# If remote branch is correct then pull the latest changes other wise clone the whole repo again

			if [ "$remote_origin_url" == "$final_repo_url" ]; then
				repo_checked_out="true"
			else
				repo_checked_out="false"
			fi
		else
			repo_checked_out="false"
		fi


		if [ "$repo_checked_out" == "false" ]; then
			echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Repository [$RULES_REPO_URL] with tag [$tag] has not been cloned yet. Please try running the script after few minutes" >> $c7n_deployer_log_file
			continue;
		fi

		# Create the Local Repo folder if it does not exist or the remote origin was not correct

		#if [ "$clone_repo" == "true" ]; then
		#	mkdir -p $LOCAL_RULES_DIR/$tag
		#	cd $LOCAL_RULES_DIR/$tag
		#	rm -rf *

		#	git clone $final_repo_url

		#	cd $RULES_REPO_NAME

		#	if [ "$tag" != "$head_name_for_master" ]; then
		#		git fetch && git fetch --tags
		#		git checkout $tag ||
		#		{
		#			echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Failed to check out tag [$tag] for account [account_id]"
		#		}
		#	fi
		#fi

		while read rules_path
		do
			# Skip empty spaces in the rules meta data file
			trimmed_rules_path=`echo ${rules_path//[[:blank:]]/}`
			if [ -z "$trimmed_rules_path" ]; then
				continue
			fi

			full_rules_path=$final_local_repo_dir/$rules_path

			echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sh $current_dir/deploy_policies_in_account.sh $full_rules_path $accounts_sub_folder_name $accounts_config_file $trimmed_rules_type $logs_dir  $account_id $tag $c7n_deployer_log_file]" >> $c7n_deployer_log_file
			sh $current_dir/deploy_policies_in_account.sh "$full_rules_path" "$accounts_sub_folder_name" "$accounts_config_file" "$trimmed_rules_type" "$logs_dir" "$account_id" "$tag" "$c7n_deployer_log_file" >> $c7n_deployer_log_file ||
			{
				echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Failed to run [sh $current_dir/deploy_policies_in_account.sh $full_rules_path $accounts_sub_folder_name $accounts_config_file $trimmed_rules_type $logs_dir  $account_id $tag $c7n_deployer_log_file]" >> $c7n_deployer_log_file
				exit 1;
			}
		done < $rules_metadata_file
	fi
  fi
done
