#!/bin/bash


current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

no_of_days_retention=$1
folder=$2

find ${folder}/* -type d -ctime +${no_of_days_retention} | xargs rm -rf

find ${folder}/* -type f -ctime +${no_of_days_retention} | xargs rm -rf
