---------------------------
## Setup Custodian Deployer
---------------------------

For detailed installation steps please refer [installation/docs/README.md](installation/docs/README.md)


---------------------------
## Running Custodian Deployer
---------------------------

Run the deploy_policies.sh script and pass the required rules type as a paramater. For example

For event based rules  
	- sh deploy_policies.sh event-based
	
For time based rules  
	- sh deploy_policies.sh time-based

To run all types of rules just do not pass any parameter  
	- sh deploy_policies.sh