#!/bin/bash

sed -i "s+{DEFAULT_ACCOUNT}+${CURRENT_ACCOUNT}+g" $LOCAL_DEPLOYER_DIR/deploy.properties

sh $LOCAL_DEPLOYER_DIR/deploy_policies.sh ${BRANCH_TYPE} ${RULE_TYPE} ${CURRENT_ACCOUNT}
