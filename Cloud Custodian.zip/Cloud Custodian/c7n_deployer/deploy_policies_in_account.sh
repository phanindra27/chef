#!/bin/bash


#current_dir="$( cd "$( dirname "$1}" )" && pwd )"

current_dir=$LOCAL_DEPLOYER_DIR

current_rules_dir=$1
accounts_folder=$2
accounts_config_file=$3
rules_type=$4
logs_dir=$5
account_id=$6
tag=$7
c7n_deployer_log_file=$8

current_timestamp=`echo $(date +"%s")`
full_repo_path=$LOCAL_RULES_DIR/$tag/$RULES_REPO_NAME
temp_files_accounts_folder=${RULES_TEMP_DIR}/${accounts_folder}
temp_rules_folder_root_dir=${temp_files_accounts_folder}/${current_timestamp}

mkdir -p $temp_rules_folder_root_dir

#echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sh $current_dir/cleanup.sh $NUM_OF_DAYS_TEMP_RETENTION $temp_files_accounts_folder]" >> $c7n_deployer_log_file
#sh $current_dir/cleanup.sh $NUM_OF_DAYS_TEMP_RETENTION "$temp_files_accounts_folder" ||
# {
#	echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Failed while calling function [sh $current_dir/cleanup.sh $NUM_OF_DAYS_TEMP_RETENTION $temp_files_accounts_folder]" >> $c7n_deployer_log_file
#}

#accounts_prefix_index=`echo $((${#ACCOUNTS_FOLDER_PREFIX}-0))`
#account_number=`echo ${accounts_folder:$accounts_prefix_index}`

echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.iam_role_arn]" >> $c7n_deployer_log_file
iam_role_arn=`cat $accounts_config_file |shyaml get-value AccountsConfig.iam_role_arn`
echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.iam_role_name]" >> $c7n_deployer_log_file
iam_role_name=`cat $accounts_config_file |shyaml get-value AccountsConfig.iam_role_name`
echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.default_region]" >> $c7n_deployer_log_file
default_region=`cat $accounts_config_file |shyaml get-value AccountsConfig.default_region`
echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.notifications_list]" >> $c7n_deployer_log_file
notifications_list=`cat $accounts_config_file |shyaml get-value AccountsConfig.notifications_list`
echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.core_filter_list]" >> $c7n_deployer_log_file
core_filter_list=`cat $accounts_config_file |shyaml get-value AccountsConfig.core_filter_list`
echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.backup_schedule]" >> $c7n_deployer_log_file
backup_schedule=`cat $accounts_config_file |shyaml get-value AccountsConfig.backup_schedule`
echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-value AccountsConfig.backup_daycount]" >> $c7n_deployer_log_file
backup_daycount=`cat $accounts_config_file |shyaml get-value AccountsConfig.backup_daycount`


copy_policies_from_directory(){
	rules_dir=$1

	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Rules Directory is [$rules_dir]" >> $c7n_deployer_log_file

	# If there are sub directories then keep calling this function until rules files are found
	# Else call the deploy_policy function and pass the policy file

	if [ `ls $rules_dir|wc -l` -gt 0 ]; then
		for rule_file in $rules_dir; do
			if [ -d "$rule_file" ]; then
				echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'copy_policies_from_directory $rule_file'" >> $c7n_deployer_log_file
				copy_policies_from_directory "$rule_file" ||
				{
					echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [copy_policies_from_directory $rule_file]" >> $c7n_deployer_log_file
				}
			else
				echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'copy_policy $rule_file'" >> $c7n_deployer_log_file
				copy_policy "$rule_file" ||
				{
					echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [copy_policy $rule_file]" >> $c7n_deployer_log_file
				}
			fi
		done
    else
        echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} No rules files exist under [$rules_dir]" >> $c7n_deployer_log_file
    fi

}

copy_policy(){
	rule_file=$1

	filename=$(basename -- "$rule_file")
  extension="${filename##*.}"
  if [[ "$extension" == "yml" ]]; then
		full_file_path=`echo "$($READLINK_COMMAND_NAME -f $rule_file)"`
		index_of_full_repo_path=`echo ${#full_repo_path}`
		trimmed_file_path=`echo ${full_file_path:$index_of_full_repo_path}`
		full_temp_file_path=${temp_rules_folder_root_dir}${trimmed_file_path}
		temp_rule_file_dir=`echo $(dirname ${full_temp_file_path})`
		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [mkdir -p $temp_rule_file_dir]" >> $c7n_deployer_log_file
		mkdir -p $temp_rule_file_dir

		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Copying rule [$rule_file] to [$full_temp_file_path]" >> $c7n_deployer_log_file
		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cp $rule_file $full_temp_file_path]" >> $c7n_deployer_log_file
		cp "$rule_file" "$full_temp_file_path"

		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'replace_place_holders $full_temp_file_path'" >> $c7n_deployer_log_file
		replace_place_holders "$full_temp_file_path" ||
		{
			echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [replace_place_holders $full_temp_file_path]" >> $c7n_deployer_log_file
		}
	else
		echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Invalid rule file format. Rule files must be in YAML format" >> $c7n_deployer_log_file
	fi
}

replace_place_holders(){
	rule_file=$1

	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Assumming IAM Role [$iam_role_arn] for Account [$account_id]" >> $c7n_deployer_log_file

	#Copy properties from the accounts_config.yml file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{IAM_ROLE_NAME}/${iam_role_name}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{IAM_ROLE_NAME}/${iam_role_name}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{CURRENT_ACCOUNT_ID}/${account_id}/g' $rule_file]" >> $c7n_deployer_log_file
    $SED_COMMAND_NAME -i "s/{CURRENT_ACCOUNT_ID}/${account_id}/g" $rule_file
    echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{WHITELIST_ACCOUNTS_URL}/${whitelist_accounts_url}/g' $rule_file]" >> $c7n_deployer_log_file
    $SED_COMMAND_NAME -i "s/{WHITELIST_ACCOUNTS_URL}/${whitelist_accounts_url}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{NOTIFICATION_RECIPIENTS_LIST}/${notifications_list}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{NOTIFICATION_RECIPIENTS_LIST}/${notifications_list}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{CORE_FILTER_LIST}/${core_filter_list}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{CORE_FILTER_LIST}/${core_filter_list}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sed -i 's/{BACKUP_SCHEDULE}/${backup_schedule}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{BACKUP_SCHEDULE}/${backup_schedule}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sed -i 's/{BACKUP_DAYCOUNT}/${backup_daycount}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{BACKUP_DAYCOUNT}/${backup_daycount}/g" $rule_file

	#Copy properties from the deploy.properties file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{DEFAULT_NOTIFICATIONS_REGION}/${DEFAULT_NOTIFICATIONS_REGION}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{DEFAULT_NOTIFICATIONS_REGION}/${DEFAULT_NOTIFICATIONS_REGION}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{DEFAULT_NOTIFICATIONS_ACCOUNT}/${DEFAULT_NOTIFICATIONS_ACCOUNT}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{DEFAULT_NOTIFICATIONS_ACCOUNT}/${DEFAULT_NOTIFICATIONS_ACCOUNT}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{DEFAULT_NOTIFICATIONS_QUEUE}/${DEFAULT_NOTIFICATIONS_QUEUE}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{DEFAULT_NOTIFICATIONS_QUEUE}/${DEFAULT_NOTIFICATIONS_QUEUE}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's+{WHITELIST_FILE_LOCATION}+${WHITELIST_FILE_LOCATION_TYPE}//${current_dir}/config/accounts/cross-account.csv+g' $rule_file]" >> $c7n_deployer_log_file
    $SED_COMMAND_NAME -i "s+{WHITELIST_FILE_LOCATION}+${WHITELIST_FILE_LOCATION_TYPE}//${current_dir}/config/accounts/accounts/cross-account.csv+g" $rule_file

	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{CURRENT_ACCOUNT}/${account_number}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{CURRENT_ACCOUNT}/${account_number}/g" $rule_file
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [$SED_COMMAND_NAME -i 's/{CLOUD_CUSTODIAN_ROLE_NAME}/${CLOUD_CUSTODIAN_ROLE_NAME}/g' $rule_file]" >> $c7n_deployer_log_file
	$SED_COMMAND_NAME -i "s/{CLOUD_CUSTODIAN_ROLE_NAME}/${CLOUD_CUSTODIAN_ROLE_NAME}/g" $rule_file
}

# Checking if the path is a directory or has multiple files under it
if [ -d "$current_rules_dir" ] || [ `ls $current_rules_dir|wc -l` -gt 0 ]; then
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'copy_policies_from_directory $current_rules_dir'" >> $c7n_deployer_log_file
	copy_policies_from_directory "$current_rules_dir" ||
	{
		echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [copy_policies_from_directory $rule_file]" >> $c7n_deployer_log_file
	}
# Checking if the path is a single file
elif [ -f "$current_rules_dir" ]; then
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'copy_policy $current_rules_dir'" >> $c7n_deployer_log_file
	copy_policy "$current_rules_dir" ||
	{
		echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [copy_policy $rule_file]" >> $c7n_deployer_log_file
	}
# Else throw an invalid path error
else
	echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Either [$current_rules_dirs] is not a valid directory or no files exist under it" >> $c7n_deployer_log_file
fi

echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [cat $accounts_config_file |shyaml get-values AccountsConfig.regions]" >> $c7n_deployer_log_file

regions=`cat "$accounts_config_file" |shyaml get-values AccountsConfig.regions`

current_date=`date +%Y-%m-%d`

c7n_local_log_prefix="c7n"

for region in $regions; do

	current_timestamp=`echo $(date +"%s")`
	log_dir="${logs_dir}/${account_id}/${region}"
	mkdir -p $log_dir

	#echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sh $current_dir/cleanup.sh $NUM_OF_DAYS_LOG_RETENTION $log_dir]" >> $c7n_deployer_log_file
	#sh $current_dir/cleanup.sh $NUM_OF_DAYS_LOG_RETENTION "$log_dir" ||
	# {
	#	echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Failed while calling function [sh $current_dir/cleanup.sh $NUM_OF_DAYS_LOG_RETENTION $log_dir]" >> $c7n_deployer_log_file
	#}

	log_file="${log_dir}/${c7n_local_log_prefix}-${current_timestamp}.log"

	touch $log_file

	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sh $current_dir/deploy_policies_in_region.sh $temp_rules_folder_root_dir $account_id $region $current_timestamp $iam_role_arn $rules_type $log_dir]" >> $log_file
	# Calling deploy policies script per region
	sh $current_dir/deploy_policies_in_region.sh $temp_rules_folder_root_dir "$account_id" "$region" "$current_timestamp" "$iam_role_arn" "$rules_type" "$log_dir" >> $log_file 2>&1

done;

current_timestamp=`echo $(date +"%s")`
log_dir="${logs_dir}/${account_id}/default"
mkdir -p $log_dir

#echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sh $current_dir/cleanup.sh $NUM_OF_DAYS_LOG_RETENTION $log_dir]" >> $c7n_deployer_log_file
#sh $current_dir/cleanup.sh $NUM_OF_DAYS_LOG_RETENTION "$log_dir" ||
# {
#	echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Failed while calling function [sh $current_dir/cleanup.sh $NUM_OF_DAYS_LOG_RETENTION $log_dir]" >> $c7n_deployer_log_file
#}

log_file="${log_dir}/${c7n_local_log_prefix}-${current_timestamp}.log"

touch $log_file

echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [sh $current_dir/deploy_region_wide_policies.sh $temp_rules_folder_root_dir $account_id $current_timestamp $iam_role_arn $default_region $rules_type $log_dir]" >> $log_file
# Calling deploy policies script region wide
sh $current_dir/deploy_region_wide_policies.sh $temp_rules_folder_root_dir "$account_id" "$current_timestamp" "$iam_role_arn" "$default_region" "$rules_type" "$log_dir" >> $log_file 2>&1
