#!/bin/bash

#current_dir="$( cd "$( dirname "$1" )" && pwd )"

current_dir=$LOCAL_DEPLOYER_DIR

temp_rules_dir=$1
account=$2
current_timestamp=$3
iam_role=$4
default_region=$5
rules_type=$6
log_dir=$7

deploy_policies_from_directory(){
	rules_dir=$1

	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Rules Directory is [$rules_dir]"

	# If there are sub directories then keep calling this function until rules files are found
	# Else call the deploy_policy function and pass the policy file

	if [ `ls $rules_dir|wc -l` -gt 0 ]; then
		cd $rules_dir
		full_rules_path=`pwd`
		for rule_file in $full_rules_path/*; do
			if [ -d "$rule_file" ]; then
				echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RULE_FILE is $rule_file"
				echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'deploy_policies_from_directory $rule_file'"
				deploy_policies_from_directory "$rule_file" ||
				{
					echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [deploy_policies_from_directory $rule_file]"
				}
			else
				echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'deploy_policy $rule_file'"
				deploy_policy "$rule_file" "$rules_dir" ||
				{
					echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Failed while calling function [deploy_policy $rule_file $rules_dir]"
				}
			fi
		done
        else
                echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} No rules files exist under [$full_rules_path]"
        fi

}

deploy_policy(){
	rule_file=$1
	rules_dir=$2

	is_rw_rule="false"

	for rw_rule_type in $REGION_WIDE_RULES; do
    		if [ "$rules_dir" == "$rw_rule_type" ]; then
			is_rw_rule="true"
			break
		fi
	done

	mode_def_wc=`cat $rule_file |shyaml get-value policies.0.mode|wc -l`
        skip_rule="false"


	filename=$(basename -- "$rule_file")
	extension="${filename##*.}"
	if [[ "$extension" == "yml" ]]; then
		# Deploy custodian policy
		echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Deploying custodian rule [$rule_file] for Account [$account]"
		if [ "$is_rw_rule" == "true" ]; then

			if [ -z "$rules_type" ]; then
                                skip_rule="false"
                        elif [[ mode_def_wc -eq 0 ]] && [[ "$rules_type" == "$EVENT_BASED_RULE_TYPE" ]]; then
                                echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Running [$EVENT_BASED_RULE_TYPE] type rules hence skipping rule [$rule_file] since its rule type is [$TIME_BASED_RULE_TYPE]"
                                skip_rule="true"
                        elif [[ mode_def_wc -gt 0 ]] && [[ "$rules_type" == "$TIME_BASED_RULE_TYPE" ]]; then
                                echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Running [$TIME_BASED_RULE_TYPE] rules hence skipping rule [$rule_file] since its rule type is [$EVENT_BASED_RULE_TYPE]"
                               skip_rule="true"
                        fi

			if [ "$skip_rule" == "true" ]; then
	                        return 1;
			else
				echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} RUNNING [custodian run --output-dir $log_dir --region $default_region --assume=$iam_role --cache-period 0 $rule_file]"
				custodian run --output-dir $log_dir --region $default_region --assume="$iam_role" --cache-period 0 $rule_file ||
				{
					echo "${C7N_DEPLOYER_ERROR_LOG_PREFIX} Failed to run [custodian run --output-dir $log_dir --region $default_region --assume=$iam_role --cache-period 0 $rule_file]"
				}
			fi
		fi
	else
		echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Invalid rule file format of file [$rule_file]. Rule files must be in YAML format"
	fi
}

if [ -d "$temp_rules_dir" ] || [ `ls $temp_rules_dir|wc -l` -gt 0 ]; then
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'deploy_policies_from_directory $temp_rules_dir'"
	deploy_policies_from_directory "$temp_rules_dir"
# Checking if the path is a single file
elif [ -f "$temp_rules_dir" ]; then
	echo "${C7N_DEPLOYER_INFO_LOG_PREFIX} Calling 'deploy_policy $temp_rules_dir'"
	deploy_policy "$temp_rules_dir"
# Else throw an invalid path error
else
	echo "${C7N_DEPLOYER_WARNING_LOG_PREFIX} Either [$temp_rules_dir] is not a valid directory or no files exist under it"
fi
