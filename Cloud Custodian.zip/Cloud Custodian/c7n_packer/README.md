## c7n packer builder

Before running these steps make sure you have "packer" installed

Follow these steps to create a new AMI

  - copy "env.var.example" file to "env.vars" file
  - Put proper values for these properties in "env.vars" file  

| Property | Description |
|  ---  |  ---  |
|RULES_REPO_USER_NAME  | This is the c7n_rules repository user name |
|RULES_REPO_APP_PASSWORD  | This is the c7n_rules repository password |
|DEPLOYER_SCRIPT_REPO_USER_NAME  | This is the c7n_deployer repository user name |
|DEPLOYER_SCRIPT_REPO_APP_PASSWORD  | This is the c7n_deployer repository password |
|DEFAULT_ACCOUNT_NUMBER  | This is default AWS Account where the c7n_deployer runs |

  - Open vars/common.json and put proper values for the following properties  
   - "source-ami": "",  (This is the source AMI ID)  
   - "branch_type": "", (This must be "tag" for Security Account and "master" for Sandbox Account)  
   - "subnet_id" : "" (This is the subnet ID to use for the temporary packer instance)

  - Open build.json and set the following property under variables
    ##### For Security Account
    "ami_name": "rhel-c7n-tag-{{timestamp}}"

    ##### For Sandbox Account
    "ami_name": "rhel-c7n-master-{{timestamp}}"

  - Go to c7n_packer root directory and run the following commands  
      - source env.vars  
      - make last
