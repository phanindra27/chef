#!/bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $current_dir/c7n_bootstrap.properties

rules_repo_url=$1
deployer_script_repo_url=$2
rules_repo_user_name=$3
rules_repo_app_password=$4
deployer_script_repo_user_name=$5
deployer_script_repo_app_password=$6
custodian_logs_bucket=$7
default_account_number=$8
default_account_region=$9
local_rules_dir=${10}
branch_type=${11}
default_notifications_queue=${12}

local_deployer_script_dir="/opt"

cd $local_deployer_script_dir

rules_repo_basename=$(basename $rules_repo_url)
rules_repo_name=${rules_repo_basename%.*}

deployer_script_repo_basename=$(basename $deployer_script_repo_url)
deployer_script_repo_name=${deployer_script_repo_basename%.*}

cloud_custodian_branch="0.8.27.3"

cloud_custodian_dir="cloud-custodian"

final_deployer_local_dir=$local_deployer_script_dir/$deployer_script_repo_name
final_rules_local_dir=$local_deployer_script_dir/$local_rules_dir

command -v git ||
{
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Git is not installed. Hence installing Git.";
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Running 'yum install -y git'";
	yum install -y git ||
	{
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error installing Git.";
		exit 1;
	}
}

command -v tox ||
{
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Tox is not installed. Hence installing Tox.";
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Running 'pip install tox'";
	pip install tox ||
	{
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error installing Tox.";
		exit 1;
	}
}

command -v shyaml ||
{
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} SHYAML is not installed. Hence installing SHYAML.";
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Running 'pip install shyaml'";
	pip install shyaml ||
	{
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error installing SHYAML.";
		exit 1;
	}
}

final_path_variable='export PATH="/usr/local/bin:$PATH"'

initial_run="false"

if grep -qF "$final_path_variable" ~/.bashrc;then
        logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Path is already up-to-date"
else
        initial_run="true"
        echo $final_path_variable >> ~/.bashrc
fi

if [ "$initial_run" == "true" ]; then
        source ~/.bashrc ||
        {
                logger "${C7N_BOOTSTRAP_WARNING_LOGS_PREFIX} Command Failed 'source ~/.bashrc'";
        }
fi

mkdir -p ${local_deployer_script_dir}/${cloud_custodian_dir}
cd ${local_deployer_script_dir}/${cloud_custodian_dir}

cloud_custodian_local_repo="${local_deployer_script_dir}/${cloud_custodian_dir}/${cloud_custodian_dir}"

clone_repo="false"

cloud_custodian_remote_repo_url="https://github.com/capitalone/cloud-custodian.git"

if [ -d $cloud_custodian_local_repo ]; then
        cd $cloud_custodian_local_repo
        remote_origin_url=`git config --get remote.origin.url`

        # If remote branch is not correct clone the whole repo again

        if [ "$remote_origin_url" != "$cloud_custodian_remote_repo_url" ]; then
			clone_repo="true"
        fi
else
        clone_repo="true"
fi

custodian_env_activate_variable="source ${local_deployer_script_dir}/${cloud_custodian_dir}/${cloud_custodian_dir}/.tox/py27/bin/activate"

# Create the Local Repo folder if it does not exist or the remote origin was not correct

if grep -qF "$custodian_env_activate_variable" ~/.bashrc;then
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Custodian environment activation variable is already up-to-date"
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Since Custodian environment activation variable is already up-to-date. Hence assumming that Cloud Custodian version [$cloud_custodian_branch] is already installed. So skipping Cloud Custodian Setup"
elif [ "$clone_repo" == "true" ]; then
	mkdir -p ${local_deployer_script_dir}/${cloud_custodian_dir}
	cd ${local_deployer_script_dir}/${cloud_custodian_dir}
	rm -rf ${cloud_custodian_dir}

	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Cloning Cloud Custodian repository 'branch $cloud_custodian_branch'.";
	git clone $cloud_custodian_remote_repo_url --branch $cloud_custodian_branch ||
	{
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error cloning Custodian Custodian Repository.";
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Command failed 'git clone $cloud_custodian_remote_repo_url --branch $cloud_custodian_branch'";
		exit 1;
	}
	echo $custodian_env_activate_variable >> ~/.bashrc

	cd ${cloud_custodian_local_repo}

	sed -i "s/RoleId/RoleName/g" c7n/resources/iam.py

	echo "Changed the 'RoleId' attribute to 'RoleName' in c7n/resources/iam.py" > change.txt

	# Building custodian repo using Tox
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Building Cloud Custodian repository using Tox."
	tox

	chmod -R 755 .tox/py27/bin/activate ||
	{
			echo "Failed running chmod"
	}
fi

#if [ "$initial_run" == "true" ]; then
#        source ~/.bashrc ||
#        {
#                echo "${C7N_BOOTSTRAP_WARNING_LOGS_PREFIX} Command Failed 'source ~/.bashrc'";
#        }
#fi

# Setup Custodian Deployer
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up Cloud Custodian Deployer."
sh $current_dir/setup_c7n_deployer.sh $deployer_script_repo_url $deployer_script_repo_user_name $deployer_script_repo_app_password ||
{
	exit_code=$?
	logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error setting up Custodian Deployer";
	exit $exit_code;
}

# Set the parameters in deploy.properties of deployer scripts

cd $final_deployer_local_dir

yes |cp deploy.properties.orig deploy.properties

logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Replacing place holders in deploy.properties."

sed -i "s+{RULES_REPO_USER}+$rules_repo_user_name+g" deploy.properties
sed -i "s+{RULES_REPO_APP_PASSWORD}+$rules_repo_app_password+g" deploy.properties
sed -i "s+{RULES_REPO_URL}+$rules_repo_url+g" deploy.properties
sed -i "s+{RULES_REPO_NAME}+$rules_repo_name+g" deploy.properties
sed -i "s+{CUSTODIAN_RULES_DIR}+$local_rules_dir+g" deploy.properties
sed -i "s+{CUSTODIAN_DEPLOYER_DIR}+$deployer_script_repo_name+g" deploy.properties
sed -i "s+{CUSTODIAN_LOGS_BUCKET}+$custodian_logs_bucket+g" deploy.properties
sed -i "s+{DEFAULT_ACCOUNT}+$default_account_number+g" deploy.properties
sed -i "s+{DEFAULT_REGION}+$default_account_region+g" deploy.properties
sed -i "s+{DEFAULT_QUEUE}+$default_notifications_queue+g" deploy.properties

source $final_deployer_local_dir/deploy.properties

# Setup Custodian Rules Repository
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up Cloud Custodian Rules Repository."
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Running 'sh $current_dir/setup_c7n_rules.sh $rules_repo_url $rules_repo_user_name $rules_repo_app_password $final_deployer_local_dir $branch_type $final_rules_local_dir'"
sh $current_dir/setup_c7n_rules.sh $rules_repo_url $rules_repo_user_name $rules_repo_app_password $final_deployer_local_dir $branch_type $final_rules_local_dir ||
{
	exit_code=$?
	logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error setting up Custodian Rules Repository";
	exit $exit_code;
}

c7n_log_group="c7n-logs"

# Setup Cloudwatch Logs Agent
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up Cloudwatch logs agent."
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Running 'sh $current_dir/setup_cw_agent.sh ${final_deployer_local_dir} ${c7n_log_group} ${default_account_region}'"
sh $current_dir/setup_cw_agent.sh "${final_deployer_local_dir}" "${c7n_log_group}" "${default_account_region}" ||
{
	exit_code=$?
	logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error setting up Cloudwatch logs agent";
	exit $exit_code;
}


# Adding a cron job for Cloud Custodian Deployer Repository
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up a cron job to fetch Cloud Custodian Deployer repository."
# Write current crontab
crontab -l > mycron
#echo new cron into cron file if it does not exists
crontab_entry="*\/5 \* \* \* \* sh $current_dir/setup_c7n_deployer.sh $deployer_script_repo_url $deployer_script_repo_user_name $deployer_script_repo_app_password"
crontab -l | grep -q "${crontab_entry}" || echo "*/5 * * * * sh $current_dir/setup_c7n_deployer.sh $deployer_script_repo_url $deployer_script_repo_user_name $deployer_script_repo_app_password" >> mycron;crontab mycron

rm -f mycron


# Adding a cron job for Cloud Custodian Rules Repository
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up a cron job to fetch Cloud Custodian Rules repository."
# Write current crontab
crontab -l > mycron
#echo new cron into cron file
crontab_entry="*\/5 \* \* \* \* sh $current_dir/setup_c7n_rules.sh $rules_repo_url $rules_repo_user_name $rules_repo_app_password $final_deployer_local_dir $branch_type $final_rules_local_dir"
crontab -l | grep -q "${crontab_entry}" || echo "*/5 * * * * sh $current_dir/setup_c7n_rules.sh $rules_repo_url $rules_repo_user_name $rules_repo_app_password $final_deployer_local_dir $branch_type $final_rules_local_dir" >> mycron;crontab mycron

rm -f mycron

# Adding a cron job for Cloudwatch log config setup
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up a cron job to fetch Cloudwatch log config setup."
# Write current crontab
crontab -l > mycron
#echo new cron into cron file
crontab_entry="*\/5 \* \* \* \* sh $current_dir/setup_cw_configs.sh $final_deployer_local_dir ${c7n_log_group}"
crontab -l | grep -q "${crontab_entry}" || echo "*/5 * * * * sh $current_dir/setup_cw_configs.sh $final_deployer_local_dir ${c7n_log_group}" >> mycron;crontab mycron

rm -f mycron


# Adding a cron job for Cloud Custodian Deployer Run for Time Based rules
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up a cron job for Cloud Custodian Deployer Run for Time Based rules."
# Write current crontab
crontab -l > mycron
#echo new cron into cron file if it does not exists
crontab_entry="0 \* \* \* \* sh $final_deployer_local_dir/deploy_policies.sh $branch_type $TIME_BASED_RULE_TYPE"
crontab -l | grep -q "${crontab_entry}" || echo "0 * * * * sh $final_deployer_local_dir/deploy_policies.sh $branch_type $TIME_BASED_RULE_TYPE" >> mycron;crontab mycron

rm -f mycron


# Adding a cron job for Cloud Custodian Deployer Run for Event Based rules
logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Setting up a cron job for Cloud Custodian Deployer Run for Event Based rules."
# Write current crontab
crontab -l > mycron
#echo new cron into cron file if it does not exists
crontab_entry="0 \*\/12 \* \* \* sh $final_deployer_local_dir/deploy_policies.sh $branch_type $EVENT_BASED_RULE_TYPE"
crontab -l | grep -q "${crontab_entry}" || echo "0 */12 * * * sh $final_deployer_local_dir/deploy_policies.sh $branch_type $EVENT_BASED_RULE_TYPE" >> mycron;crontab mycron

rm -f mycron
