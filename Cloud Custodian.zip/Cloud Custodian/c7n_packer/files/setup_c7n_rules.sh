#!/bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $current_dir/c7n_bootstrap.properties

rules_repo_url=$1
rules_repo_user_name=$2
rules_repo_app_password=$3
deployer_local_dir=$4
branch_type=$5
local_rules_dir=$6

source $deployer_local_dir/deploy.properties

local_rules_script_dir="/opt"

head_name_for_tag="HEAD"
head_name_for_master="master"

rules_repo_basename=$(basename $rules_repo_url)
rules_repo_name=${rules_repo_basename%.*}

# Clone the deployer script repo
final_repo_url="https://$rules_repo_user_name:$rules_repo_app_password@$rules_repo_url"
final_local_repo_dir=$local_rules_script_dir/$rules_repo_name

final_rules_repo_url="https://$rules_repo_user_name:$rules_repo_app_password@$rules_repo_url"

# Iterate over the accounts folders and deploy rules as per the meta data file
for accounts_sub_dir in $deployer_local_dir/config/accounts/Account*; do
  if [ -d "$accounts_sub_dir" ]; then
	rules_metadata_file="$accounts_sub_dir/rules_metadata.txt"
	accounts_config_file="$accounts_sub_dir/accounts_config.yml"
	accounts_sub_folder_name=`echo $(basename $accounts_sub_dir)`
	if [ ! -f "$rules_metadata_file" ]; then
		logger "${C7N_BOOTSTRAP_WARNING_LOGS_PREFIX} Rules Metadata file [$rules_metadata_file] does not exist in [$accounts_sub_dir]"
		continue
	elif [ ! -f "$accounts_config_file" ]; then
		logger "${C7N_BOOTSTRAP_WARNING_LOGS_PREFIX} Accounts file [$accounts_config_file] does not exist in [$accounts_sub_dir]"
		continue
	else
	  	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} RUNNING 'cat $accounts_config_file |shyaml get-value AccountsConfig.account_id'"
		account_id=`cat $accounts_config_file |shyaml get-value AccountsConfig.account_id`
		rules_version=`cat $accounts_config_file |shyaml get-value AccountsConfig.rules_version`

		logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} RUNNING [git ls-remote --tags $final_repo_url| awk '{print \$2}' | grep -v '{}' | awk -F"/" '{print \$3}' | sort -n -t. -k1,1 -k2,2 -k3,3| tail -1]"
		latest_tag=`git ls-remote --tags $final_rules_repo_url| awk '{print \$2}' | grep -v '{}' | awk -F"/" '{print \$3}' | sort -n -t. -k1,1 -k2,2 -k3,3| tail -1`

    if [ "$rules_version" == "$head_name_for_master" ]; then
      tag=$head_name_for_master
    elif [ ${#rules_version} -eq 0 ]; then
			if [ ${#latest_tag} -eq 0 ]; then
			     tag=$head_name_for_master
			else
			     tag=$latest_tag
			fi
		else
			remote_tags_ls_count=`git ls-remote --tags $final_repo_url $rules_version`

			if [ ${#remote_tags_ls_count} -eq 0 ]; then
			     remote_heads_ls_count=`git ls-remote --heads $final_repo_url $rules_version`
			fi

			if [[ ${#remote_tags_ls_count} -gt 0 ]] || [[ ${#remote_heads_ls_count} -gt 0 ]]; then
			     tag=$rules_version
			elif [ ${#latest_tag} -eq 0 ]; then
			     tag=$head_name_for_master
			else
			     tag=$latest_tag
			fi

		fi

		if [[ ( "$tag" != "$head_name_for_master" && "$branch_type" == "$RULES_MASTER_REPO_TYPE" ) || ( "$tag" == "$head_name_for_master" && "$branch_type" != "$RULES_MASTER_REPO_TYPE" ) ]]; then
		    logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Running branch type [$branch_type]. Account [$account_id] is on tag [$tag], hence skipping this account."
		      continue;
		fi

		logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Account [$account_id] is using version [$tag] rules"

		final_local_repo_dir=$local_rules_dir/$tag/$rules_repo_name
		clone_repo="false"

		# First lets check if the Local Rules Folder exists and it is Git Repo
		if [ -d $final_local_repo_dir ]; then
			cd $final_local_repo_dir
			remote_origin_url=`git config --get remote.origin.url`

			# If remote branch is correct then pull the latest changes other wise clone the whole repo again

			if [ "$remote_origin_url" == "$final_repo_url" ]; then
				if [ "$tag" == "$head_name_for_master" ]; then
					#git fetch origin
					#difference=`git diff`
					#difference_size=${#difference}
          #echo "Account [$account_id] and Difference is $difference_size"
					#if [ $difference_size -gt 0 ]; then
						git pull ||
  					{
  						logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Error pulling changes from Custodian Rules Repository.";
  						logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Command failed 'git pull'";
  						exit 1;
  					}
					#fi
				fi
			else
				clone_repo="true"
			fi
		else
			clone_repo="true"
		fi


		# Create the Local Repo folder if it does not exist or the remote origin was not correct

		if [ "$clone_repo" == "true" ]; then
			mkdir -p $local_rules_dir/$tag
			cd $local_rules_dir/$tag
			rm -rf *

			git clone $final_repo_url

			cd $rules_repo_name

			if [ "$tag" != "$head_name_for_master" ]; then
				git fetch && git fetch --tags
				git checkout $tag ||
				{
					logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Failed to check out tag [$tag] for account [account_id]"
				}
			fi
		fi
	fi
  fi
done
