#!/bin/bash

sudo mkdir /opt
sudo chmod -R 755 /opt
