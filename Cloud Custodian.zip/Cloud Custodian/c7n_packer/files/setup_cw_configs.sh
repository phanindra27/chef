#!/bin/bash

current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $current_dir/c7n_bootstrap.properties

deployer_local_dir=$1
custodian_log_group=$2

local_dir="/opt"
actual_cw_conf_file="/var/awslogs/etc/awslogs.conf"

c7n_local_log_prefix="c7n"

# Iterate over the accounts folders and deploy rules as per the meta data file
for accounts_sub_dir in ${deployer_local_dir}/config/accounts/Account*; do
  if [ -d "$accounts_sub_dir" ]; then
	accounts_config_file="$accounts_sub_dir/accounts_config.yml"
	accounts_sub_folder_name=`echo $(basename $accounts_sub_dir)`
	if [ ! -f "$accounts_config_file" ]; then
		logger "${C7N_BOOTSTRAP_ERROR_LOGS_PREFIX} Accounts file [$accounts_config_file] does not exist in [$accounts_sub_dir]"
		continue
	else
	  	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} RUNNING 'cat $accounts_config_file |shyaml get-value AccountsConfig.account_id'"
		account_id=`cat $accounts_config_file |shyaml get-value AccountsConfig.account_id`

		regions=`cat "$accounts_config_file" |shyaml get-values AccountsConfig.regions`

		for region in $regions; do

			config_occurence_count=`grep -rnw ${actual_cw_conf_file} -e "\[${account_id}\/${region}\]"|wc -l`

			configs_changed="false"

			if [ $config_occurence_count -eq 0 ];then

        logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Adding configuration section for [${account_id}/${region}]"
				# Add the configs here
				echo "[${account_id}/${region}]" >> ${actual_cw_conf_file}
				echo "datetime_format = %b %d %H:%M:%S" >> ${actual_cw_conf_file}
				echo "file = ${deployer_local_dir}/logs/${account_id}/${region}/${c7n_local_log_prefix}-*.log" >> ${actual_cw_conf_file}
				echo "buffer_duration = 5000" >> ${actual_cw_conf_file}
				echo "log_stream_name = /${account_id}/${region}" >> ${actual_cw_conf_file}
				echo "initial_position = start_of_file" >> ${actual_cw_conf_file}
				echo "log_group_name = ${custodian_log_group}" >> ${actual_cw_conf_file}
        echo "batch_count = 100" >> ${actual_cw_conf_file}
        echo "" >> ${actual_cw_conf_file}
        echo "" >> ${actual_cw_conf_file}

				configs_changed="true"
			fi

      deployer_prefix="deployer"

      config_occurence_count=`grep -rnw ${actual_cw_conf_file} -e "\[${deployer_prefix}\]"|wc -l`

      if [ $config_occurence_count -eq 0 ];then

        logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Adding configuration section for [$deployer_prefix]"
				# Add the configs here
				echo "[$deployer_prefix]" >> ${actual_cw_conf_file}
				echo "datetime_format = %b %d %H:%M:%S" >> ${actual_cw_conf_file}
				echo "file = ${deployer_local_dir}/logs/${deployer_prefix}/${deployer_prefix}-*.log" >> ${actual_cw_conf_file}
				echo "buffer_duration = 5000" >> ${actual_cw_conf_file}
				echo "log_stream_name = /${deployer_prefix}" >> ${actual_cw_conf_file}
				echo "initial_position = start_of_file" >> ${actual_cw_conf_file}
				echo "log_group_name = ${custodian_log_group}" >> ${actual_cw_conf_file}
        echo "batch_count = 100" >> ${actual_cw_conf_file}
        echo "" >> ${actual_cw_conf_file}
        echo "" >> ${actual_cw_conf_file}

				configs_changed="true"
			fi


		done;

	fi
  fi
done

if [ "$configs_changed" == "true" ];then
	logger "${C7N_BOOTSTRAP_INFO_LOGS_PREFIX} Cloudwatch log agent configuration has been changed. Hence restarting logs."
	service awslogs restart
fi
