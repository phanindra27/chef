#!/bin/bash -eux

# rules_repo_url=$1
# deployer_script_repo_url=$2
# rules_repo_user_name=$3
# rules_repo_app_password=$4
# deployer_script_repo_user_name=$5
# deployer_script_repo_app_password=$6
# custodian_logs_bucket=$7
# default_account_number=$8
# default_account_region=$9
# local_rules_dir=${10}
# branch_type=${11}

deployer_script_repo_url=$DEPLOYER_SCRIPT_REPO_URL
rules_repo_user_name=$RULES_REPO_USER_NAME
rules_repo_app_password=$RULES_REPO_APP_PASSWORD
deployer_script_repo_user_name=$DEPLOYER_SCRIPT_REPO_USER_NAME
deployer_script_repo_app_password=$DEPLOYER_SCRIPT_REPO_APP_PASSWORD
custodian_logs_bucket=$CUSTODIAN_LOGS_BUCKET
cloud_custodian_role=$cloud_custodian_role
default_account_number=$DEFAULT_ACCOUNT_NUMBER
default_account_region=$DEFAULT_ACCOUNT_REGION
local_rules_dir=$LOCAL_RULES_DIR
local_deployer_dir=$LOCAL_DEPLOYER_DIR
local_deployer_script_dir="/opt"

command -v python36 ||
{
	logger "${INFO_LOGS_PREFIX} python36 is not installed.";
	logger "${INFO_LOGS_PREFIX} Installing epel && python36";
	rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
	yum install -y python36 ||
	{
		logger "${ERROR_LOGS_PREFIX} Error installing python36.";
		exit 1;
	}
}

command -v pip ||
{
	logger "${INFO_LOGS_PREFIX} pip is not installed.";
	logger "${INFO_LOGS_PREFIX} Installing pip";
	yum install -y python-pip ||
	{
		logger "${ERROR_LOGS_PREFIX} Error installing pip.";
		exit 1;
	}
}

sh $SCRIPT_DIR/c7n_bootstrap.sh $RULES_REPO_URL $DEPLOYER_SCRIPT_REPO_URL $RULES_REPO_USER_NAME $RULES_REPO_APP_PASSWORD $DEPLOYER_SCRIPT_REPO_USER_NAME $DEPLOYER_SCRIPT_REPO_APP_PASSWORD $CUSTODIAN_LOGS_BUCKET $DEFAULT_ACCOUNT_NUMBER $DEFAULT_ACCOUNT_REGION $LOCAL_RULES_DIR $BRANCH_TYPE $DEFAULT_NOTIFICATIONS_QUEUE
